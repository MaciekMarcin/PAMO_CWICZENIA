package com.pjwstk.bmi_3;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {

    Button button1, button2, button3, button4;

    TextView scoreTextView, questionTextView;

    private Questions kQuestions = new Questions();

    private String kChoices;
    private int mScore = 0;
    private int kQuestionsLenght = kQuestions.kQuestions.length;


    Random r;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        r = new Random();

        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        scoreTextView = (TextView) findViewById(R.id.scoreTextView);
        questionTextView = (TextView) findViewById(R.id.questionTextView);

        scoreTextView.setText("Score: " + mScore);

        updateQuestion(r.nextInt(kQuestionsLenght));

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (button1.getText() == kChoices){
                    mScore++;
                    scoreTextView.setText("Score: " + mScore);
                    updateQuestion(r.nextInt(kQuestionsLenght));
                } else {
                        gameOver();
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (button2.getText() == kChoices){
                    mScore++;
                    scoreTextView.setText("Score: " + mScore);
                    updateQuestion(r.nextInt(kQuestionsLenght));
                } else {
                    gameOver();
                }
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (button3.getText() == kChoices){
                    mScore++;
                    scoreTextView.setText("Score: " + mScore);
                    updateQuestion(r.nextInt(kQuestionsLenght));
                } else {
                    gameOver();
                }
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (button4.getText() == kChoices){
                    mScore++;
                    scoreTextView.setText("Score: " + mScore);
                    updateQuestion(r.nextInt(kQuestionsLenght));
                } else {
                    gameOver();
                }
            }
        });
    }

    private void updateQuestion(int num){
        questionTextView.setText(kQuestions.getQuestion(num));
        button1.setText(kQuestions.getChoice1(num));
        button2.setText(kQuestions.getChoice2(num));
        button3.setText(kQuestions.getChoice3(num));
        button4.setText(kQuestions.getChoice4(num));

        kChoices = kQuestions.getCorrectAnswer(num);
    }

    private void gameOver() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Main2Activity.this);
        alertDialogBuilder
                .setMessage("Game Over! Your score is: " + mScore)
                .setCancelable(false)
                .setPositiveButton("NEW GAME",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(new Intent(getApplicationContext(), Main2Activity.class));
                            }
                        })
                .setNegativeButton("EXIT",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                finish();
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
