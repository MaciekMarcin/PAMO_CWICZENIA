package com.pjwstk.bmi_3;

public class Questions {

    public String kQuestions[] = {
            "Ile powinna jeść osoba chuda?",
            "Co ile należy jeść?",
            "Czego nie może zabraknąć w diecie?",
            "Co należy robić codziennie?",
            "Co należy robić aby utrzymać sylwetkę?"
    };

    private String kChoices[][] = {
            {"Dużo", "Mało", "Tyle ile chce", "Ponad kilo"},
            {"Co 4-6 godzin", "Co 7 godzin", "Co 2-3 godziny", "Co godzinę"},
            {"Owoców i warzyw", "Frytury", "Cukru", "Chęci do życia"},
            {"Malować sufit", "Trzepać dywan", "Pić wodę", "Chodzić do Biedronki"},
            {"Wykonywać ćwiczenia", "Często odwiedzać lodówkę", "Robić pierogi", "Mieszać bigos głową"}

    };

    private String kAnswers[] = {"Dużo", "Co 2-3 godziny", "Owoców i warzyw", "Pić wodę", "Wykonywać ćwiczenia"};

    public String getQuestion(int a){
        String Question = kQuestions[a];
        return Question;
    }

    public String getChoice1(int a){
        String choice = kChoices[a][0];
        return choice;
    }

    public String getChoice2(int a){
        String choice = kChoices[a][1];
        return choice;
    }

    public String getChoice3(int a){
        String choice = kChoices[a][2];
        return choice;
    }

    public String getChoice4(int a){
        String choice = kChoices[a][3];
        return choice;
    }

    public String getCorrectAnswer(int a){
        String answer = kAnswers[a];
        return answer;
    }

}
