package com.pjwstk.bmi_3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class Main3Activity extends AppCompatActivity {
    private WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        webview = (WebView) findViewById(R.id.webview);
        WebSettings webSettings = webview.getSettings();
        webview.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        webSettings.setJavaScriptEnabled(true);
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        final String htmlData = "<html>"
                +"  <head>"
                +"    <script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>"
                +"    <script type=\"text/javascript\">"
                +"      google.charts.load('current', {'packages':['corechart']});"
                +"      google.charts.setOnLoadCallback(drawChart);"

                +"      function drawChart() {"

                +"        var data = google.visualization.arrayToDataTable(["
                +"          ['Type', 'Percentage'],"
                +"          ['Underweight',     17],"
                +"          ['Normal',      45],"
                +"          ['Overweight',  23],"
                +"          ['Obese', 15]"
                +"        ]);"

                +"        var options = {"
                +"          title: 'BMI distribution among people'"

                +"        };"

                +"        var chart = new google.visualization.PieChart(document.getElementById('piechart'));"

                +"        chart.draw(data, options);"
                +"      }"
                +"    </script>"
                +"  </head>"
                +"  <body>"
                +"    <div id=\"piechart\" style=\"width: 200px; height: 200px;\"></div>"
                +"  </body>"
                +"</html>";
        webview.clearCache(true);
        webview.clearHistory();
        webview.loadDataWithBaseURL(null, htmlData, null, "utf-8", null);
        //webview.postDelayed(new Runnable() {
//
        //    @Override
         //   public void run() {
         //       webview.loadUrl(htmlData);
         //   }
       // }, 500);
        //webview.loadData(htmlData, "text/html", "UTF-8");
    }
}
