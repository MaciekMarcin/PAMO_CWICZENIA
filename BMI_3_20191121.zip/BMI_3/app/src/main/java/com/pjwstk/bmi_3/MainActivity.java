package com.pjwstk.bmi_3;

import android.content.Intent;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
//import java.util.HashMap;
//import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private TextView mTextMessage;
    private ConstraintLayout startContainer;
    private ConstraintLayout calculatorContainer;
    private ConstraintLayout dishContainer;

    private double mass = 0.0;
    private double height = 0.0;
    private int age = 0;
    //public int s;
    private String gender;
    private Button quizButton;
    private Button chartButton;

    private TextView massTextView;
    private TextView heightTextView;
    private TextView resultTextView;
    private TextView bmiTextView;
    private TextView titleTextView;
    private TextView descriptionTextView;
    private TextView ageTextView;
    private TextView resultMuffinTextView;
    private TextView dishTextView;
    private TextView dishDescTextView;
    private ImageView dishImageView;

    //private CheckBox maleCheckBox;
    //private CheckBox femaleCheckBox;

    private Spinner genderSpinner;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_start:
                    //mTextMessage.setText(R.string.title_start);
                    startContainer.setVisibility(startContainer.VISIBLE);
                    calculatorContainer.setVisibility(calculatorContainer.INVISIBLE);
                    dishContainer.setVisibility(dishContainer.INVISIBLE);
                    return true;
                case R.id.navigation_calculator:
                    //mTextMessage.setText(R.string.title_calculator);
                    startContainer.setVisibility(startContainer.INVISIBLE);
                    calculatorContainer.setVisibility(calculatorContainer.VISIBLE);
                    dishContainer.setVisibility(dishContainer.INVISIBLE);
                    return true;
                case R.id.navigation_dish:
                    //mTextMessage.setText(R.string.title_dish);
                    startContainer.setVisibility(startContainer.INVISIBLE);
                    calculatorContainer.setVisibility(calculatorContainer.INVISIBLE);
                    dishContainer.setVisibility(dishContainer.VISIBLE);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        mTextMessage = findViewById(R.id.message);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        chartButton = (Button) findViewById(R.id.chartButton);
        quizButton = (Button) findViewById(R.id.quizButton);
        massTextView = (TextView) findViewById(R.id.massTextView);
        heightTextView = (TextView) findViewById(R.id.heightTextView);
        resultTextView = (TextView) findViewById(R.id.resultTextView);
        bmiTextView = (TextView) findViewById(R.id.bmiTextView);
        titleTextView = (TextView) findViewById(R.id.titleTextView);
        descriptionTextView = (TextView) findViewById(R.id.descriptionTextView);
        ageTextView = (TextView) findViewById(R.id.ageTextView) ;
        startContainer = (ConstraintLayout) findViewById(R.id.startContainer);
        calculatorContainer = (ConstraintLayout) findViewById(R.id.calculatorContainer);
        dishContainer = (ConstraintLayout) findViewById(R.id.dishContainer);
        resultMuffinTextView = (TextView) findViewById(R.id.resultMuffinTextView);
        dishTextView = (TextView) findViewById(R.id.dishTextView);
        dishDescTextView = (TextView) findViewById(R.id.dishDescTextView);
        dishImageView = (ImageView) findViewById(R.id.dishImageView);

        //maleCheckBox = (CheckBox) findViewById(R.id.maleCheckBox);
        //femaleCheckBox = (CheckBox) findViewById(R.id.femaleCheckBox);

        startContainer.setVisibility(startContainer.VISIBLE);
        calculatorContainer.setVisibility(calculatorContainer.INVISIBLE);
        dishContainer.setVisibility(dishContainer.INVISIBLE);

        /*
        // get references to programmatically manipulated TextViews
        amountTextView = (TextView) findViewById(R.id.amountTextView);
        percentTextView = (TextView) findViewById(R.id.percentTextView);
        tipTextView = (TextView) findViewById(R.id.tipTextView);
        totalTextView = (TextView) findViewById(R.id.totalTextView);
        tipTextView.setText(currencyFormat.format(0));
        totalTextView.setText(currencyFormat.format(0));
        */

        EditText massEditText = (EditText) findViewById(R.id.massEditText);
        massEditText.addTextChangedListener(massEditTextWatcher);

        EditText heightEditText = (EditText) findViewById(R.id.heightEditText);
        heightEditText.addTextChangedListener(heightEditTextWatcher);

        EditText ageEditText = (EditText) findViewById(R.id.ageEditText);
        ageEditText.addTextChangedListener(ageEditTextWatcher);

        /*final Spinner */genderSpinner = (Spinner) findViewById(R.id.genderSpinner);

        quizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });

        chartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity3();
            }
        });

        genderSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //gender = genderSpinner.getSelectedItem().toString();
                //String selectedClass = parent.getItemAtPosition(position).toString();
                gender = adapterView.getItemAtPosition(i).toString();
                Toast.makeText(MainActivity.this, "\n Plec: \t " + gender, Toast.LENGTH_LONG).show();
                calculate();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
                gender = "MALE"; //Ten fragment i tak jest zbedny
            }
        });

        /*
        // set amountEditText's TextWatcher
        EditText amountEditText = (EditText) findViewById(R.id.amountEditText);
        amountEditText.addTextChangedListener(amountEditTextWatcher);

        // set percentSeekBar's OnSeekBarChangeListener
        SeekBar percentSeekBar = (SeekBar) findViewById(R.id.percentSeekBar);
        percentSeekBar.setOnSeekBarChangeListener(seekBarListener);
        */

        massTextView.setText("Mass:");
        heightTextView.setText("Height:");
        bmiTextView.setText("Your BIM is: ");
        resultTextView.setText("There is noting");
        ageTextView.setText("Age: ");
        resultMuffinTextView.setText("There is noting");
        titleTextView.setText("OMNIPOTENT 2.0");
        descriptionTextView.setText("Application to calculate BMI / MPP and to support a healthy lifestyle.");
        dishTextView.setText("");
        dishDescTextView.setText("");
        dishImageView.setVisibility(View.INVISIBLE);

        String[] items = new String[]{"MALE", "FEMALE"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        genderSpinner.setAdapter(adapter);


    }

    public void openActivity2() {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }

    public void openActivity3() {
        Intent intent = new Intent(this, Main3Activity.class);
        startActivity(intent);
    }

    // calculate and display tip and total amounts
    private void calculate () {
        // format percent and display in percentTextView
        //percentTextView.setText(percentFormat.format(percent));
        double bmi = (mass / (height * height) * 100);
        bmi = (float) Math.round(bmi);// ZAKOMENTOWANE BO ZAOKRĄGLA DO CALOSCI
        String type="";
        if (mass > 0 && height > 0) {
            dishImageView.setVisibility(View.VISIBLE);
            // calculate the tip and total
            //double tip = billAmount * percent;
            //double total = billAmount + tip;

            // display tip and total formatted as currency
            bmiTextView.setText("Your BIM is: " + bmi);
            //tipTextView.setText(currencyFormat.format(tip));
            //totalTextView.setText(currencyFormat.format(total));
            if (bmi < 10 || bmi < 100) {
                if (bmi == 0.0) {
                    resultTextView.setText("There is noting");
                } else if (bmi < 18.5) {
                    resultTextView.setText("Underweight");
                    type="Underweight";
                } else if (bmi >= 18.5 && bmi < 25) {
                    resultTextView.setText("Normal weight");
                    type="Normal weight";
                } else if (bmi >= 25 && bmi < 30) {
                    resultTextView.setText("Overweight");
                    type="Overweight";
                } else if (bmi >= 30) {
                    resultTextView.setText("Obese");
                    type="Obese";
                } else {
                    resultTextView.setText("Error");
                }
            } else {
                resultTextView.setText("That's far fetched");
            }
        }
        //double mpp = ((10*mass)+(6.25*height)-(5*age)+s);
        //double mpp;// = (10*mass)+(6.25*height)-(5*age);
        //resultMuffinTextView.setText("You should eat around " + mpp + " calories per day");
        if(gender != null) {
            if (gender== "MALE") {
                double mpp = (10 * (100 * mass)) + (6.25 * (100 * height)) - (5 * age) + 5;
                resultMuffinTextView.setText("MPP MALE: " + mpp + " calories");
            } else if (gender == "FEMALE") {
                double mpp = (10 * (100 * mass)) + (6.25 * (100 * height)) - (5 * age) - 161;
                resultMuffinTextView.setText("MPP FEMALE: " + mpp + " calories");
            } else {
                double mpp = (10 * (100 * mass)) + (6.25 * (100 * height)) - (5 * age);
                resultMuffinTextView.setText("MPP genderless: " + mpp + " calories");
            }
        }

        if(type=="Underweight") {
            dishTextView.setText("Traditional polish dinner");
            dishDescTextView.setText("You should try eating a healthy polish dinner, especially an schabowy with potatoes and coleslav.");
            dishImageView.setImageResource(R.drawable.schab);
        } else if(type=="Normal weight")  {
            dishTextView.setText("Rice");
            dishDescTextView.setText("Rice is a safe option, even with a large quantinity of meat to it. It shouldn't kill you.");
            dishImageView.setImageResource(R.drawable.rice);
        } else if(type=="Overweight") {
            dishTextView.setText("Salad");
            dishDescTextView.setText("It's not too bad if you do it yourself.");
            dishImageView.setImageResource(R.drawable.salad);
        } else if(type=="Obese") {
            dishTextView.setText("Bread and water");
            dishDescTextView.setText("Diet won't help you with anything at this point without exercises so eat pretty often small amounts of food. Mostly something light.");
            dishImageView.setImageResource(R.drawable.bread);
        } else {
            dishTextView.setText("");
            dishDescTextView.setText("");
        }

    }

    // listener object for the EditText's text-changed events
    private final TextWatcher massEditTextWatcher = new TextWatcher() {
        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            try { // get bill amount and display currency formatted value
                mass = Double.parseDouble(s.toString()) / 100.0;
                //massTextView.setText(massFormat.format(mass));
            }
            catch (NumberFormatException e) { // if s is empty or non-numeric
                massTextView.setText("Mass: ");
                mass = 0.0;
            }
            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
    };

    private final TextWatcher heightEditTextWatcher = new TextWatcher() {
        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            try { // get bill amount and display currency formatted value
                height = Double.parseDouble(s.toString()) / 100.0;
                //heightTextView.setText(heightFormat.format(height));
            }
            catch (NumberFormatException e) { // if s is empty or non-numeric
                heightTextView.setText("Height: ");
                height = 0.0;
            }
            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
    };

    private final TextWatcher ageEditTextWatcher = new TextWatcher() {
        // called when the user modifies the bill amount
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            try { // get bill amount and display currency formatted value
                age = Integer.parseInt(s.toString());
                //heightTextView.setText(heightFormat.format(height));
            }
            catch (NumberFormatException e) { // if s is empty or non-numeric
                ageTextView.setText("Age: ");
                age = 0;
            }

            calculate(); // update the tip and total TextViews
        }

        @Override
        public void afterTextChanged(Editable s) { }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
    };
}
